document.getElementById("settings").onclick = () => chrome.runtime.openOptionsPage();
