---
name: "➕ New addons"
about: New addons
title: "[New addon] ..."
labels: new-addons
assignees: ""
---

**Describe the new addon**

<!-- A description of the new addon. -->

**Link to the new addon**

<!-- Add a link to the new addon here. -->
